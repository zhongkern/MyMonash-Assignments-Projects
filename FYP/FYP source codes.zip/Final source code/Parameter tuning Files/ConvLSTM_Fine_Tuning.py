#!/usr/bin/env python
# coding: utf-8

# In[2]:

import scipy.io as sio
import numpy as np
import csv
import os

# Machine Learning
from tensorflow.keras import backend as K
from tensorflow.keras import layers
from tensorflow.python.keras.models import Sequential
from tensorflow.keras.models import load_model
from sklearn.utils import shuffle
from sklearn.model_selection import train_test_split
from tensorflow.keras.optimizers import Adam
from sklearn.model_selection import StratifiedKFold
from tensorflow.keras.utils import to_categorical
from tensorflow.keras.callbacks import ModelCheckpoint

# Optimizer
from skopt import gp_minimize#, forest_minimize
from skopt.space import Real, Categorical, Integer
from skopt.plots import plot_convergence

from tensorflow.keras.layers import Dense, Flatten, MaxPooling3D,BatchNormalization, Dropout, ConvLSTM2D

# Optimizer
from skopt import gp_minimize  # , forest_minimize
from skopt.space import Real, Categorical, Integer
from skopt.plots import plot_convergence

# results directory
RES_DIR = 'csv_files/'
if not os.path.exists(RES_DIR):
    os.makedirs(RES_DIR)
# models directory
MODELS_DIR = 'models/'
if not os.path.exists(MODELS_DIR):
    os.makedirs(MODELS_DIR)

K_SEED = 330
no_folds = 5


# In[3]:


def init_opt_parmas():
    init_learning_rate = Real(low=1e-6, high=1e-2, prior='log-uniform', name='learning_rate')

    # max CNN layers
    max_conv_layers = Integer(low=1, high=3, name='num_conv_layers')
    # max Dense layers
    max_fc_layers = Integer(low=1, high=2, name='num_fc_layers')

    # CNN-1 kernel size
    kernel_size1 = Categorical(categories=[3, 4, 5], name='kernel_size1')
    # CNN-2 kernel size
    kernel_size2 = Categorical(categories=[3, 4, 5], name='kernel_size2')
    # CNN-3 kernel size
    kernel_size3 = Categorical(categories=[3, 4, 5], name='kernel_size3')

    # CNN-1 num conv filters
    conv_filters1 = Categorical(categories=[16,32, 64], name='conv_filters1')
    # CNN-2 num conv filters
    conv_filters2 = Categorical(categories=[16,32, 64], name='conv_filters2')
    # CNN-3 num conv filters
    conv_filters3 = Categorical(categories=[16,32, 64], name='conv_filters3')

    dropout1 = Categorical(categories=[0.0, 0.2, 0.4, 0.5], name='dropout1')
    dropout2 = Categorical(categories=[0.0, 0.2, 0.4, 0.5], name='dropout2')
    dropout3 = Categorical(categories=[0.0, 0.2, 0.4, 0.5], name='dropout3')

    recurrant_dropout1 = Categorical(categories=[0.0, 0.2, 0.4, 0.5], name='recurrant1')
    recurrant_dropout2 = Categorical(categories=[0.0, 0.2, 0.4, 0.5], name='recurrant2')
    recurrant_dropout3 = Categorical(categories=[0.0, 0.2, 0.4, 0.5], name='recurrant3')

    # CNN pool size
    pool_size1 = Categorical(categories=[1, 2, 4, 6], name='pool_size1')
    pool_size2 = Categorical(categories=[ 6, 8, 10, 12], name='pool_size2')

    # num Dense-1 nodes
    dense_nodes1 = Categorical(categories=[32, 64, 128, 256], name='dense_nodes1')
    # num Dense-2 nodes
    dense_nodes2 = Categorical(categories=[32, 64, 128, 256], name='dense_nodes2')
    # Dense dropout
    ratio_dropout = Categorical(categories=[0.0, 0.2, 0.4, 0.5], name='ratio_dropout')

    # "batch_size":,
    batch_size = Categorical(categories=[2,3,4], name='batch_size')

    strides = Categorical(categories=[2, 4, 6], name='strides')

    dimensions = [init_learning_rate, max_conv_layers, max_fc_layers,
                  kernel_size1, kernel_size2, kernel_size3,
                  conv_filters1, conv_filters2, conv_filters3,
                  dropout1, dropout2, dropout3,
                  recurrant_dropout1, recurrant_dropout2, recurrant_dropout3,
                  pool_size1, pool_size2,
                  dense_nodes1, dense_nodes2,
                  ratio_dropout, batch_size, strides]

    default_parameters = [0.001, 2, 2,
                          3, 4, 5,
                          64, 32, 32,
                          0.2, 0.0, 0.4,
                          0.2, 0.0, 0.4,
                          2, 6,
                          128, 32,
                          0.4, 3, 2]
    return dimensions, default_parameters


def load_data():
    file_name = 'conn_mat_20.csv'
    # load correlation data
    conn_mat = [0] * 45
    for i in range(45):
        conn_mat[i] = [0] * 20
        for j in range(20):
            conn_mat[i][j] = [0] * 116

    row_count = 0
    matrix_count = 0
    patient = 0
    # total_count = 0

    with open(file_name, mode='r') as f:
        data = csv.reader(f, delimiter=',')
        for row in data:
            lst = []
            for item in row:
                lst.append(float(item))  # list of 116 items

            conn_mat[patient][matrix_count][row_count] = lst

            row_count += 1
            # total_count += 1
            if row_count >= 116:
                row_count = 0
                matrix_count += 1
                if matrix_count >= 20:
                    matrix_count = 0
                    patient += 1

    data = conn_mat
    data = np.expand_dims(data, -1)
    # the folder path where the MATLAB files are stored
    # dataPath = 'mdd_fmri_data.mat'
    dataPath = 'mdd_fmri_data.mat'

    # load correlation data
    labels = sio.loadmat(dataPath)['labels']
    # shrink the dimension of labels vector to one-dimentional
    labels = np.squeeze(labels)
    # find the total number of classes from the labels vector
    num_classes = len(np.unique(labels))
    labels = labels.flatten()

    return data, labels, num_classes

# not being used in this code
def norm_data(X):
    # keepdims makes the result shape (1, 1, 3) instead of (3,). 
    # This doesn't matter here, but would matter if you wanted to
    #  normalize over a different axis.
    X_min = X.min(axis=(0, 1), keepdims=True)
    X_max = X.max(axis=(0, 1), keepdims=True)
    X = (X - X_min) / (X_max - X_min)
    return X


# #### > CNN model 
def build_model(args, data_shape_full):
    model = Sequential()
    kernel_size1 = (args.kernel_size[0], args.kernel_size[0])

    model.add(layers.ConvLSTM2D(filters=args.conv_filters[0], kernel_size=kernel_size1, dropout=args.dropout[0],
                                recurrent_dropout=args.recurant_dropout[0],
                                return_sequences=True, activation='relu', input_shape=data_shape_full))
    model.add(layers.BatchNormalization(momentum=0.9))
    pool_size = (args.pool_size1, args.pool_size2, args.pool_size2)
    model.add(layers.AveragePooling3D(pool_size=pool_size, padding='same', strides=args.strides))
    if args.max_conv_layers > 1:
        kernel_size2 = (args.kernel_size[1], args.kernel_size[1])
        model.add(layers.ConvLSTM2D(filters=args.conv_filters[1], kernel_size=kernel_size2,
                                    dropout=args.dropout[1],return_sequences=True,
                                    recurrent_dropout=args.recurant_dropout[1],
                                    activation='relu'))
        model.add(layers.BatchNormalization(momentum=0.9))
        pool_size = (args.pool_size1, args.pool_size2, args.pool_size2)
        model.add(layers.AveragePooling3D(pool_size=pool_size, padding='same', strides=args.strides))
    if args.max_conv_layers > 2:
        kernel_size3 = (args.kernel_size[2], args.kernel_size[2])
        model.add(layers.Conv2D(filters=args.conv_filters[2], kernel_size=kernel_size3,
                                dropout=args.dropout[1],return_sequences=True,
                                recurrent_dropout=args.recurant_dropout[1],
                                activation='relu'))
        model.add(layers.BatchNormalization(momentum=0.9))
        pool_size = (args.pool_size1, args.pool_size2, args.pool_size2)
        model.add(layers.AveragePooling3D(pool_size=pool_size, padding='same', strides=args.strides))

    model.add(layers.Flatten())

    model.add(layers.Dense(args.dense_nodes[0], activation='relu'))
    model.add(layers.Dropout(args.ratio_dropout))
    if args.max_fc_layers > 1:
        model.add(layers.Dense(args.dense_nodes[1], activation='relu'))
        model.add(layers.Dropout(args.ratio_dropout))

    model.add(layers.Dense(args.num_classes, activation='softmax'))

    opt = Adam(lr=args.base_lr)
    model.compile(optimizer=opt,
                  loss='categorical_crossentropy',
                  metrics=['accuracy'])

    return model


# %%
def incr():
    global count
    count += 1
    return count


def fitness(argspace):
    count = incr()
    print('Opt. Iter No    :', count)
    args = type('', (), {})()
    args.base_lr = argspace[0]
    print('learn_rate      : {0:.1e}'.format(args.base_lr))
    args.max_conv_layers = argspace[1]
    args.max_fc_layers = argspace[2]
    args.kernel_size = sorted(argspace[3:3 + args.max_conv_layers], reverse=False)
    print('CNN_kernel_size :', args.kernel_size)
    args.conv_filters = sorted(argspace[6:6 + args.max_conv_layers], reverse=True)
    print('CNN_conv_filters:', args.conv_filters)
    args.dropout = sorted(argspace[9:9 + args.max_conv_layers], reverse=False)
    print('Dropouts:', args.dropout)
    args.recurant_dropout = sorted(argspace[12:12 + args.max_conv_layers], reverse=False)
    print('Recurant_Dropouts:', args.recurant_dropout)
    args.pool_size1 = argspace[15]
    args.pool_size2 = argspace[16]
    print('CNN_pool_size1   :', args.pool_size1)
    print('CNN_pool_size2   :', args.pool_size1)
    args.dense_nodes = sorted(argspace[17:17 + args.max_fc_layers], reverse=True)
    print('Dense_nodes     :', args.dense_nodes)
    args.ratio_dropout = argspace[19]
    print('Dense_dropout   :', args.ratio_dropout)
    args.batch_size = argspace[20]
    print('Batch_size      :', args.batch_size)
    args.strides = argspace[21]
    print('Stride      :', args.strides)
    # load data
    fc_data, labels, num_classes = load_data()
    print(fc_data.shape)
    

    '''
    conver FC arrays to 3D array for Conv2D compatibility
    '''

    args.num_classes = num_classes

    val_accs = np.zeros(no_folds)
    train_accs = np.zeros(no_folds)
    test_accs = np.zeros(no_folds)

    kf = StratifiedKFold(n_splits=5, shuffle=True, random_state=K_SEED)
    i_fold = 0
    for _train_idx, test_idx in kf.split(fc_data, labels):
        _kf = StratifiedKFold(n_splits=5, shuffle=True, random_state=K_SEED)
        train_idx, val_idx = next(_kf.split(fc_data[_train_idx], labels[_train_idx]))
        train_idx, val_idx = _train_idx[train_idx], _train_idx[val_idx]

        train_data, test_data, valid_data, y_train, y_test, y_valid = \
            fc_data[train_idx], fc_data[test_idx], fc_data[val_idx], \
            labels[train_idx], labels[test_idx], labels[val_idx]

        #  Create one-hot encode of integer labels
        train_labels = to_categorical(y_train, num_classes)
        valid_labels = to_categorical(y_valid, num_classes)
        test_labels = to_categorical(y_test, num_classes)

        data_shape_full = train_data.shape[1:]

        # Build model                 
        model = build_model(args, data_shape_full)

        # Use Keras to train the model.
        filename = MODELS_DIR + 'best_model.hdf5'
        checkpointer = ModelCheckpoint(filepath=filename, monitor='val_accuracy', verbose=0,
                                       save_best_only=True)
        history = model.fit(x=train_data,
                            y=train_labels,
                            epochs=20,
                            batch_size=args.batch_size,
                            validation_data=(valid_data, valid_labels),
                            verbose=0,
                            callbacks=[checkpointer])

        val_acc_epochs = history.history['val_accuracy']  # best val score
        best_epoch = np.argmax(val_acc_epochs)
        val_accs[i_fold] = val_acc_epochs[best_epoch]

        train_acc_epochs = history.history['accuracy']  # best train score
        train_accs[i_fold] = train_acc_epochs[best_epoch]

        del model
        model = load_model(filename)
        _, test_accs[i_fold] = model.evaluate(test_data, test_labels, verbose=0)

        i_fold += 1

    global best_train_accs, best_test_accs
    best_train_accs.append(np.mean(train_accs))
    best_test_accs.append(np.mean(test_accs))

    print("Val   Accuracy: {0:.2%}".format(np.mean(val_accs)))
    print("Test  Accuracy: {0:.2%}".format(np.mean(test_accs)))
    print("Train Accuracy: {0:.2%}".format(np.mean(train_accs)))
    print()

    K.clear_session()
    return -np.mean(val_accs)


# %%    
def run_hyp_opt(dimensions, default_parameters, fun):
    search_result = gp_minimize(func=fun,
                                dimensions=dimensions,
                                acq_func='EI',  # Expected Improvement.
                                n_calls=20,
                                x0=default_parameters)

    plot_convergence(search_result)
    search_result.x
    # space = search_result.space
    # space.point_to_dict(search_result.x)
    search_result.fun
    x = sorted(zip(search_result.func_vals, best_train_accs, best_test_accs, search_result.x_iters))  # best_test_accs
    return x


# %%

def run():
    dims, default_params = init_opt_parmas()
    x = run_hyp_opt(dims, default_params, fitness)

    import csv
    csvfile = RES_DIR + "optimized_LSTM_params.csv"
    # Assuming x is a list of lists
    with open(csvfile, "w") as output:
        writer = csv.writer(output, lineterminator='\n')
        writer.writerows(x)

    # %%


if __name__ == '__main__':
    count = 0
    best_train_accs = []
    best_test_accs = []

    run()