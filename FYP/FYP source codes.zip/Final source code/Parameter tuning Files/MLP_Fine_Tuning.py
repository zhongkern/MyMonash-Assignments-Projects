#!/usr/bin/env python
# coding: utf-8

# In[2]:


# General
import scipy.io as sio
import numpy as np
import os

# Machine Learning
from tensorflow.keras import backend as K
from tensorflow.keras import layers
from tensorflow.python.keras.models import Sequential
from tensorflow.keras.models import load_model
from sklearn.utils import shuffle
from sklearn.model_selection import train_test_split
from tensorflow.keras.optimizers import Adam
from sklearn.model_selection import StratifiedKFold
from tensorflow.keras.utils import to_categorical
from tensorflow.keras.callbacks import ModelCheckpoint

# Optimizer
from skopt import gp_minimize#, forest_minimize
from skopt.space import Real, Categorical, Integer
from skopt.plots import plot_convergence


# results directory
RES_DIR = 'csv_files/'
if not os.path.exists(RES_DIR):
    os.makedirs(RES_DIR)
#models directory
MODELS_DIR = 'models/'
if not os.path.exists(MODELS_DIR):
    os.makedirs(MODELS_DIR)

K_SEED = 420
no_folds = 5

# In[3]:
    
def init_opt_parmas():
    init_learning_rate = Real(low=1e-6, high=1e-2, prior='log-uniform', name='learning_rate')
    
    max_fc_layers = Integer(low=1, high=4, name='num_fc_layers')
    
    # num Dense-1 nodes
    dense_nodes1 = Categorical(categories=[32,64,128,256,512], name='dense_nodes1')
    # num Dense-2 nodes
    dense_nodes2 = Categorical(categories=[32,64,128,256,512], name='dense_nodes2')
        # num Dense-1 nodes
    dense_nodes3 = Categorical(categories=[32,64,128,256,512], name='dense_nodes3')
    # num Dense-2 nodes
    dense_nodes4 = Categorical(categories=[32,64,128,256,512], name='dense_nodes4')

    activation_1 =  Categorical(categories=['tanh','relu','sigmoid'], name = 'activation_1')
    
    activation_2 = Categorical(categories=['tanh','relu','sigmoid'], name = 'activation_2')
    
    activation_3 = Categorical(categories=['tanh','relu','sigmoid'], name = 'activation_3')
    
    activation_4 = Categorical(categories=['tanh','relu','sigmoid'], name = 'activation_4')
    #"batch_size":,
    batch_size = Categorical(categories=[5,6,8,10], name='batch_size')
    dropout = Categorical(categories=[0.0,0.1,0.2,0.3,0.4,0.5,0.6], name='dropout')
    
    dimensions = [init_learning_rate, max_fc_layers,
                  dense_nodes1, dense_nodes2, dense_nodes3, dense_nodes4,
                  activation_1, activation_2, activation_3, activation_4,
                  batch_size,dropout ]
    
    default_parameters = [0.001, 4,
                          64, 32, 32,64,
                         'relu','relu','relu','relu',
                         5, 0.2]
    return dimensions, default_parameters

def load_data():
    dataPath = 'static_corr_func_conn.mat'
    # load correlation data
    data = sio.loadmat(dataPath)['funConn']
    data = np.stack([A[np.triu_indices_from(A, k=1)] for A in data])
    # load labels. 0: healthy, 1: mdd 
    labels = sio.loadmat(dataPath)['labels']
    # shrink the dimension of labels vector to one-dimentional
    labels = np.squeeze(labels)
    # find the total number of classes from the labels vector
    number_of_classes = len(np.unique(labels))
    return data, labels, number_of_classes

# not being used in this code
def norm_data(X):
    # keepdims makes the result shape (1, 1, 3) instead of (3,). 
    # This doesn't matter here, but would matter if you wanted to
    #  normalize over a different axis.
    X_min = X.min(axis=(0, 1), keepdims=True)
    X_max = X.max(axis=(0, 1), keepdims=True)
    X = (X - X_min)/(X_max - X_min)
    return X


# #### > CNN model 
def build_model(args,data_shape_full):

    model = Sequential()
    model.add(layers.Dense(args.dense_nodes[0], activation = args.activation[0],kernel_initializer='he_normal', input_shape=(6670,)))
    
    model.add(layers.BatchNormalization(momentum=0.9))
    model.add(layers.Dropout(args.dropout))
    if args.max_fc_layers>1:
       model.add(layers.Dense(args.dense_nodes[1], activation = args.activation[1],kernel_initializer='he_normal'))
    
       model.add(layers.BatchNormalization(momentum=0.9))
       model.add(layers.Dropout(args.dropout))
    if args.max_fc_layers>2:
        model.add(layers.Dense(args.dense_nodes[2], activation = args.activation[2],kernel_initializer='he_normal'))
    
        model.add(layers.BatchNormalization(momentum=0.9))
        model.add(layers.Dropout(args.dropout))
    if args.max_fc_layers>3:
        model.add(layers.Dense(args.dense_nodes[3], activation = args.activation[3],kernel_initializer='he_normal'))
    
        model.add(layers.BatchNormalization(momentum=0.9))
        model.add(layers.Dropout(args.dropout))    
        
    
    model.add(layers.Dense(args.num_classes, activation='softmax'))
    
    opt = Adam(lr=args.base_lr)  
    model.compile( optimizer=opt,
                   loss='categorical_crossentropy',
                   metrics=['accuracy'] ) 
    
    return model

#%%
def incr():
     global count
     count += 1
     return count
 
def fitness(argspace):
    
    count = incr()
    print('Opt. Iter No    :', count)
    args = type('',(),{})()
    args.base_lr = argspace[0]
    print('learn_rate      : {0:.1e}'.format(args.base_lr))
    args.max_fc_layers = argspace[1]
    args.dense_nodes = sorted(argspace[2:2 + args.max_fc_layers],reverse = True)
    print('Dense Nodes :',args.dense_nodes)
    args.activation = argspace[6:6+args.max_fc_layers]
    print('activations:',args.activation)
    args.batch_size = argspace[10]
    print('Batch_size      :',args.batch_size)
    args.dropout = argspace[11]
    # load data
    fc_data, labels, num_classes = load_data()
    
    '''
    conver FC arrays to 3D array for Conv2D compatibility
    '''
    
    # fc_data = np.stack((fc_data,)*3, axis=-1) # 3D array (RGB image-like)
    
    args.num_classes = num_classes
    
    val_accs = np.zeros(no_folds)
    train_accs = np.zeros(no_folds)
    test_accs = np.zeros(no_folds)
    
    kf = StratifiedKFold(n_splits=5, shuffle=True, random_state=K_SEED)
    i_fold = 0
    for _train_idx, test_idx in kf.split(fc_data,labels):
        _kf = StratifiedKFold(n_splits=5, shuffle=True, random_state=K_SEED)
        train_idx, val_idx = next(_kf.split(fc_data[_train_idx],labels[_train_idx]))
        train_idx, val_idx = _train_idx[train_idx], _train_idx[val_idx]
        
        train_data, test_data, valid_data, y_train, y_test, y_valid = \
            fc_data[train_idx], fc_data[test_idx], fc_data[val_idx], \
            labels[train_idx], labels[test_idx], labels[val_idx]
        
        #  Create one-hot encode of integer labels
        train_labels = to_categorical(y_train, num_classes)
        valid_labels = to_categorical(y_valid, num_classes)
        test_labels = to_categorical(y_test, num_classes)
        
        data_shape_full = train_data.shape[1:]
        
        # Build model                 
        model = build_model(args,data_shape_full)
        
        # Use Keras to train the model.
        filename = MODELS_DIR + 'best_model.hdf5'
        checkpointer = ModelCheckpoint(filepath=filename, monitor='val_accuracy', verbose=0,  
                                   save_best_only=True)
        history = model.fit(x=train_data,
                            y=train_labels,
                            epochs=100,
                            batch_size=args.batch_size,
                            validation_data=(valid_data,valid_labels),
                            verbose=0,
                            callbacks=[checkpointer])
        
        val_acc_epochs = history.history['val_accuracy'] #best val score
        best_epoch = np.argmax(val_acc_epochs)
        val_accs[i_fold] = val_acc_epochs[best_epoch]
        
        train_acc_epochs = history.history['accuracy'] #best train score
        train_accs[i_fold] = train_acc_epochs[best_epoch]
        
        del model
        model = load_model(filename)
        _,test_accs[i_fold] = model.evaluate(test_data, test_labels, verbose=0)
        
        i_fold += 1
        
    global best_train_accs, best_test_accs
    best_train_accs.append(np.mean(train_accs))
    best_test_accs.append(np.mean(test_accs))

    print("Val   Accuracy: {0:.2%}".format(np.mean(val_accs)))
    print("Test  Accuracy: {0:.2%}".format(np.mean(test_accs)))
    print("Train Accuracy: {0:.2%}".format(np.mean(train_accs)))
    print()
    
    K.clear_session()
    return -np.mean(val_accs)

#%%    
def run_hyp_opt(dimensions,default_parameters,fun):
    search_result = gp_minimize(func=fun,
                                dimensions=dimensions,
                                acq_func='EI', # Expected Improvement.
                                n_calls=150,
                                x0=default_parameters)
    
    plot_convergence(search_result)
    search_result.x
    #space = search_result.space
    #space.point_to_dict(search_result.x)
    search_result.fun
    x = sorted(zip(search_result.func_vals, best_train_accs, best_test_accs, search_result.x_iters))#best_test_accs
    return x    
#%%
        
def run():   
    
    dims, default_params = init_opt_parmas()
    x = run_hyp_opt(dims,default_params,fitness)
        
    import csv
    csvfile = RES_DIR + "optimized_MLP_params_2.csv"
    #Assuming x is a list of lists
    with open(csvfile, "w") as output:
        writer = csv.writer(output, lineterminator='\n')
        writer.writerows(x)        

#%%
if __name__ == '__main__':
    
    count = 0
    best_train_accs = []
    best_test_accs = []
    
    run()