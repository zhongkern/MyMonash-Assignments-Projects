# package used to load MATLAB fil
import scipy.io as sio
import scipy.signal
import scipy.stats as stats
from matplotlib import pyplot as plt
import numpy as np
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
import csv
#The file "mdd_fmri_data.mat" contains two variables:
#	1- "fmridata" of shape (116,150,45) --> (nodes, time points, subjects #).
#	2- "labels" of shape (45,1) (subjects #, 1), the data labels 1: MDD, 0: Healthy control.

# the folder path where the MATLAB files are stored
dataPath = 'mdd_fmri_data.mat'

# load correlation data
data = sio.loadmat(dataPath)['fmridata']
label = sio.loadmat(dataPath)['labels']

# print the first voxel of all 45 patients out to visualise data
# =============================================================================
# fig=plt.figure(figsize=(20,20))
# for i in range(45):
#     lst=[]
#     for item in data[0]:
#         lst.append(item[i])
# 
#     fig.add_subplot(9,5,i+1,xticks=[],yticks=[], xlabel=label[i])
#     plt.plot(lst)
#     
# plt.show()
# =============================================================================

# print the all 116 voxels of patient 0
# fig=plt.figure(figsize=(15,15))
# nodes_length = len(data)

# for i in range(nodes_length):
#     lst=[]
#     for item in data[i]:
#         lst.append(item[0])
#     fig.add_subplot(10,15,i+1,xticks=[],yticks=[],xlabel="Node"+str(i+1))
#     plt.plot(lst)
# plt.show()


# =============================================================================
# fig, axs = plt.subplots(5)
# 
# for i in range(5):
#     lst = []
#     for j in range(len(data[0])):
#         lst.append(data[0][j][0])
#     axs[i].plot(lst)
#     axs[i].axis('off') 
#     
#     
# plt.show()
# ========================================================================


# =============================================================================
# 
# no_nodes = 116
# values = []
# rows = no_nodes
# cols = no_nodes
# conn_mat = [0] * rows # generate a 2d array with all 0 
# for i in range(no_nodes):
#     conn_mat[i]= ([0]* cols)
# 
# # add the values of the data that are being looked at to calculate the matrix
# window_length = 10
# # create a 2D array where the each element contains a window_length number of observations of the respective node
# for i in range(no_nodes):
#     lst = []
#     for j in range(window_length):
#         lst.append(data[i][j][0])
#     values.append(lst)
# 
#     
# #print(values)
# #now it is time to calculate the values of the connectivity matrix using our previous array
# for i in range(no_nodes):
#     for j in range(no_nodes):
#         #if i == j:
#             #print(stats.pearsonr(values[i],values[j])
#         conn_mat[i][j] = (stats.pearsonr(values[i],values[j]))[0] # take the first element of pearsonr function
#         #print("i:",i,",j:",j,"val:",conn_mat[i][j] )
# 
# 
# plt.imshow(conn_mat)

# =============================================================================
# Code to make all matrices of all pateints

# no_nodes = 116
# values = []
# rows = no_nodes
# cols = no_nodes
# window_length = 50
# stride_length = 1
# total_time = int((150 - window_length) / stride_length)
# file_name = 'conn_mat.csv'
# 
# with open(file_name, mode='w') as f:
#     pass
# 
# 
# for y in range(45):
#     start = 0
#     stop = 50
#     for z in range(total_time):
#         conn_mat = [0] * rows # generate a 2d array with all 0 
#         for i in range(no_nodes):
#             conn_mat[i]= ([0]* cols)
#         
#         # add the values of the data that are being looked at to calculate the matrix
#         # create a 2D array where the each element contains a window_length number of observations of the respective node
#         for i in range(no_nodes):
#             lst = []
#             for j in range(start,stop):
#                 lst.append(data[i][j][y])
#             values.append(lst)
#         
#             
#         #print(values)
#         #now it is time to calculate the values of the connectivity matrix using our previous array
#         for i in range(no_nodes):
#             for j in range(no_nodes):
#                 #if i == j:
#                     #print(stats.pearsonr(values[i],values[j])
#                 conn_mat[i][j] = (stats.pearsonr(values[i],values[j]))[0] # take the first element of pearsonr function
#                 #print("i:",i,",j:",j,"val:",conn_mat[i][j] )
#         
#         #convert to numpy array to save in a csv
#         arr = np.array(conn_mat)
#         #np.savetxt('conn_mat.csv', arr, delimiter =',')
#         
#         with open(file_name, 'a+', newline='') as write_obj:
#             # Create a writer object from csv module
#             csv_writer = csv.writer(write_obj)
#             # Add contents of list as last row in the csv file
#             csv_writer.writerows(arr)
#         # change some variables
#         start += stride_length
#         stop += stride_length
# =============================================================================
file_name = 'conn_mat.csv'

# create our connectivity matrix of dimension 45 x 100 x 116 x116
conn_mat = [0] * 45
for i in range(45):
    conn_mat[i] = [0] * 100
    for j in range(100):
        conn_mat[i][j] = [0] * 116
        

row_count = 0
matrix_count = 0
patient = 0
#total_count = 0

with open(file_name, mode = 'r') as f:
    data = csv.reader(f, delimiter = ',')
    for row in data:
        lst = []
        for item in row:
            lst.append(float(item)) # list of 116 items
            
        conn_mat[patient][matrix_count][row_count] = lst
        
        row_count += 1
        #total_count += 1
        if row_count >= 116:
            row_count = 0
            matrix_count += 1
            if matrix_count >= 100:
                matrix_count = 0
                patient += 1
        #print("row_count:{0}   , matrix_count:{1}   , patient:{2}, total:{3}".format(row_count,matrix_count,patient,total_count))

#print("finished")
