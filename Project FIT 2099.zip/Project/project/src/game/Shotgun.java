/**
 * 
 */
package game;

import edu.monash.fit2099.engine.WeaponItem;

/**
 * The base class for creating an instance of a shotgun
 * @author Teh Qi Yuan
 *
 */
public class Shotgun extends WeaponItem {

	public Shotgun() {
		super("shotgun", 'S', 35,  "shot");
		// TODO Auto-generated constructor stub
	}
	
	
	
}
