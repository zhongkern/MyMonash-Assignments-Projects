/**
 * 
 */
package game;

/**
 * @author Teh Qi Yuan
 * A class for sniper bullet
 *
 */
public class SniperBullet extends Bullet {

	public SniperBullet() {
		super("SniperBullet",'>');
		// TODO Auto-generated constructor stub
	}

}
