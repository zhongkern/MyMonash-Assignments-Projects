/**
 * 
 */
package game;

import edu.monash.fit2099.engine.WeaponItem;

/**
 * @author Teh Qi Yuan
 * 
 * A base class for creating a sniper rifle weapon
 *
 */
public class SniperRifle extends WeaponItem {

	public SniperRifle() {
		super("Sniper", '?', 35, "fire");
		// TODO Auto-generated constructor stub
	}
	
	

}
