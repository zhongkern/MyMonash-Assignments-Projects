package game;

public enum ZombieCapability {
	UNDEAD, //zombies
	ALIVE,   // human
	UNSEEN	// Mambo
}
