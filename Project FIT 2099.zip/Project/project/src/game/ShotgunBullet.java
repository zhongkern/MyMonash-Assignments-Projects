/**
 * 
 */
package game;

/**
 * @author Teh Qi Yuan
 * A class for shotgun bullet
 */
public class ShotgunBullet extends Bullet {

	public ShotgunBullet() {
		super("Shotgun Bullet", '<');
		// TODO Auto-generated constructor stub
	}

	
}
